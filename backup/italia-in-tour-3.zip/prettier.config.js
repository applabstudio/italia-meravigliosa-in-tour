module.exports = {
  singleQuote: false,
  semi: false,
}
